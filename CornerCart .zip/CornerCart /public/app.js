// public/app.js

import { supabase } from './supabaseClient.js'

// Utility: simplify element creation
function createElement(tag, attrs = {}, ...children) {
  const el = document.createElement(tag)
  for (const [key, value] of Object.entries(attrs)) {
    if (key === 'class') el.className = value
    else if (key.startsWith('on')) el[key] = value
    else el.setAttribute(key, value)
  }
  for (const child of children) {
    if (typeof child === 'string') el.appendChild(document.createTextNode(child))
    else if (child) el.appendChild(child)
  }
  return el
}

// Handle user signup
document.getElementById('signup-form').addEventListener('submit', async (e) => {
  e.preventDefault()
  const email = e.target.elements['email'].value
  const password = e.target.elements['password'].value
  const { data, error } = await supabase.auth.signUp({ email, password })
  if (error) {
    alert('Signup error: ' + error.message)
  } else {
    alert('Signup successful! Please check your email to confirm.')
  }
})

// Handle user login
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault()
  const email = e.target.elements['email'].value
  const password = e.target.elements['password'].value
  const { data, error } = await supabase.auth.signIn({ email, password })
  if (error) {
    alert('Login error: ' + error.message)
  } else {
    alert('Logged in as ' + data.user.email)
    // Optionally hide login form, show products, etc.
  }
})

// Fetch and display products
async function loadProducts() {
  const { data: products, error } = await supabase.from('products').select('*')
  if (error) { console.error('Error loading products', error); return }
  const container = document.getElementById('products')
  container.innerHTML = ''
  products.forEach(product => {
    const card = createElement('div', { class: 'product-card' },
      createElement('h3', {}, product.name),
      createElement('p', {}, product.description || ''),
      createElement('p', {}, 'Price: $' + product.price.toFixed(2)),
      createElement('button', {
        onclick: () => addToCart(product.id)
      }, 'Add to Cart')
    )
    container.appendChild(card)
  })
}

// In-memory cart: array of {product_id, qty}
let cart = []

function addToCart(productId) {
  const item = cart.find(i => i.product_id === productId)
  if (item) {
    item.qty += 1
  } else {
    cart.push({ product_id: productId, qty: 1 })
  }
  alert('Added to cart!')
}

// Submit order: call the Edge Function
document.getElementById('checkout-button').addEventListener('click', async () => {
  if (cart.length === 0) {
    alert('Your cart is empty.')
    return
  }
  const { data, error } = await supabase.functions.invoke('create-order', {
    body: { items: cart }
  })
  if (error) {
    console.error('Order error:', error)
    alert('Error placing order: ' + error.message)
  } else {
    alert('Order placed! Order ID: ' + data.orderId)
    cart = []
  }
})

// On page load
loadProducts()