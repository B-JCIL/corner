// functions/create-order.ts

import { createClient } from 'npm:@supabase/supabase-js@2'

Deno.serve(async (req: Request) => {
  try {
    // Initialize Supabase client with auth context (RLS enforced as needed)
    const supabaseClient = createClient(
  Deno.env.get('PROJECT_URL')!,      // instead of SUPABASE_URL
  Deno.env.get('ANON_KEY')!,         // instead of SUPABASE_ANON_KEY
  {
    global: {
      headers: { Authorization: req.headers.get('Authorization')! }
    }
  }
)

    // Parse cart items from request body
    const { items } = await req.json().catch(() => ({}))
    if (!items || !Array.isArray(items)) {
      return new Response('Invalid cart data', { status: 400 })
    }

    // Authenticate user from JWT
    const token = req.headers.get('Authorization')?.replace('Bearer ', '')
    if (!token) return new Response('Unauthorized', { status: 401 })
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token)
    if (userError || !userData.user) {
      return new Response('Authentication failed', { status: 401 })
    }
    const userId = userData.user.id

    // Check stock and compute total
    let total = 0
    for (const item of items) {
      // Check inventory
      const { data: invData, error: invError } = await supabaseClient
        .from('inventory')
        .select('quantity')
        .eq('product_id', item.product_id)
        .single()
      if (invError || !invData) {
        return new Response(`Inventory not found for product ${item.product_id}`, { status: 400 })
      }
      if (invData.quantity < item.qty) {
        return new Response(`Not enough stock for product ${item.product_id}`, { status: 400 })
      }
      // Get product price
      const { data: prodData, error: prodError } = await supabaseClient
        .from('products')
        .select('price')
        .eq('id', item.product_id)
        .single()
      if (prodError || !prodData) {
        return new Response(`Product ${item.product_id} not found`, { status: 400 })
      }
      total += prodData.price * item.qty
    }

    // Create order record
    const { data: orderData, error: orderError } = await supabaseClient
      .from('orders')
      .insert({ user_id: userId, total })
      .select('id')
      .single()
    if (orderError || !orderData) {
      return new Response('Failed to create order', { status: 500 })
    }
    const orderId = orderData.id

    // Insert order items and decrement stock
    for (const item of items) {
      // Re-fetch price (could reuse above, simplified here)
      const { data: prodData } = await supabaseClient
        .from('products')
        .select('price')
        .eq('id', item.product_id)
        .single()
      const price = prodData.price
      // Insert order item
      await supabaseClient.from('order_items').insert({
        order_id: orderId,
        product_id: item.product_id,
        quantity: item.qty,
        price
      })
      // Update inventory
      const { data: invCurrent } = await supabaseClient
        .from('inventory')
        .select('quantity')
        .eq('product_id', item.product_id)
        .single()
      const newQty = invCurrent.quantity - item.qty
      await supabaseClient
        .from('inventory')
        .update({ quantity: newQty })
        .eq('product_id', item.product_id)
    }

    // Success response with order ID
    return new Response(JSON.stringify({ orderId }), { status: 200 })
  } catch (err) {
    console.error('Error in create-order function:', err)
    return new Response('Server error', { status: 500 })
  }
})