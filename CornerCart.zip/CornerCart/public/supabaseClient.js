// public/supabaseClient.js

// Import Supabase client library (via CDN)
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm'

// TODO: Replace with your Supabase project URL and anon key
const SUPABASE_URL = 'https://ykwkzqelkpoiveudppys.supabase.co'
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlrd2t6cWVsa3BvaXZldWRwcHlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU1MTc2ODUsImV4cCI6MjA3MTA5MzY4NX0.QbFZ0L7ASHaK4ednhbnJbRqHNhhIKwqPCpikLc4dCl8'

// Create a single Supabase client instance
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)