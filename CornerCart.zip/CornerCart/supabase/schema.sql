-- supabase/schema.sql

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  image_url TEXT,
  category_id INTEGER REFERENCES categories(id)
);

-- Inventory table (one row per product for stock quantity)
CREATE TABLE IF NOT EXISTS inventory (
  product_id INTEGER PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
  quantity INTEGER NOT NULL DEFAULT 0
);

-- Orders table (one per checkout)
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL,
  total NUMERIC(10,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Order items (junction table: which products in each order)
CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL,
  price NUMERIC(10,2) NOT NULL  -- price at time of order
);

-- Seed initial data
INSERT INTO categories (name) VALUES 
  ('Electronics'), ('Books'), ('Clothing')
ON CONFLICT DO NOTHING;

INSERT INTO products (name, description, price, image_url, category_id) VALUES
  ('Laptop', 'A powerful laptop computer', 999.99, 'images/laptop.png', 1),
  ('Novel', 'A thrilling mystery novel', 14.99, 'images/novel.png', 2),
  ('T-Shirt', '100% cotton T-shirt', 19.99, 'images/tshirt.png', 3)
ON CONFLICT DO NOTHING;

INSERT INTO inventory (product_id, quantity) VALUES
  (1, 5), (2, 12), (3, 20)
ON CONFLICT (product_id) DO NOTHING;